# Simple To-Do List

This is a basic To-Do List web application built with **HTML**, **CSS**, and **TypeScript (compiled to JavaScript)**.

### Features:
- Add new tasks
- Delete tasks from the list
- Responsive and clean design

This project was created as a learning exercise.
